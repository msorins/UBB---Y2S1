public class Main {
    public static void main(String[] args) {
        Solution sol = new Solution();
        try {
            sol.solve();
        } catch (Exception e) {
            e.printStackTrace();
        }
        ;

    }
}
